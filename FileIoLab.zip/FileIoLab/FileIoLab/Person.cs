﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileIoLab
{
    public class Person : IComparable<Person>
    {
        private string FirstName
            {
            get;
            init;
            }
        private string LastName
        {
            get;
            init;
        }
        private Address Address
        {
            get;
            init;
        }
        public Person(string firstName, string lastName, Address address)
        {
            this.FirstName = firstName;
            this.LastName = lastName;
            this.Address = address;
        }
        public override string ToString()
        {
            return
                $"{FirstName}" + "|" + $"{LastName}" + "|" + $"{Address.ToString()}";
        }
        public int CompareTo(Person? other)
        {
            return String.Compare(this.LastName, other.LastName);
        }
    }

}
