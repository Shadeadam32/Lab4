﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileIoLab
{
    public class Address
    {
        private string StreetAddress
        { get; init; }
        private string City
        { get; init; }
        private string PostalCode
        { get; init; }
        private string State
        { get; init; }  

        public Address(string streetAddress, string city, string state, string postalCode)
        {
            this.StreetAddress = streetAddress;
            this.City = city;
            this.State = state;
            this.PostalCode = postalCode;
        }
        public override string ToString()
        {
            return
                $"{StreetAddress}" + "|" + $"{City}" + "|" + $"{PostalCode}" + "|" + $"{State}"; 
        }
    }
}
