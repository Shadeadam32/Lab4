﻿using FileIoLab;

string root = FileRoot.projectRoot;
string csvFile = root + Path.DirectorySeparatorChar + "data.csv";
string psvFile = root + Path.DirectorySeparatorChar + "data.pvs";

List<Person> people = new List<Person>();
List<Address> homes = new List<Address>();

using (StreamReader sr = new StreamReader(csvFile))
{
    while (!sr.EndOfStream)
    {
        string line = sr.ReadLine();
        var info = line.Split(",");

        var firstName = info[0];
        var lastName = info[1];
        var streetAddress = info[2];
        var city = info[3];
        var state = info[4];
        var postalCode = info[5];

        homes.Add(new Address(streetAddress, city, state, postalCode));
        people.Add(new Person(firstName, lastName, homes[homes.Count - 1]));
    }
}

people.Sort();

using (StreamWriter sw = new StreamWriter(psvFile))
{
    foreach (Person p in people)
    {
        // interpolated string
        string line = p.ToString();
        sw.WriteLine(line);
    }
}