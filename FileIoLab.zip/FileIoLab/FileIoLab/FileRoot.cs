﻿
    internal class FileRoot {
    public static string projectRoot = Directory.GetParent(Directory.GetCurrentDirectory()).Parent.Parent.ToString();
}

